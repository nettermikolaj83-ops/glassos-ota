"""GlassOS: the shared local AI engine (llama.cpp's llama-server).

One server per user, started on demand with the model chosen in Asystent AI
(~/.local/share/glassos-ai/config.json) and shared by the app, Spotlight
("? question") and the text tools (Super+Shift+A). A watchdog stops it after
IDLE_MIN minutes without use, so the RAM is free again.

Installed as /usr/local/lib/glassos/aiclient.py.
"""
import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.request

DATA = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "glassos-ai")
MODELS = os.path.join(DATA, "models")
CFG = os.path.join(DATA, "config.json")
RUN = os.environ.get("XDG_RUNTIME_DIR") or "/tmp"
STATE = os.path.join(RUN, "glassos-ai-server.json")
USED = os.path.join(RUN, "glassos-ai-server.used")
SERVER = "/usr/local/bin/glassos-llama-server"
IDLE_MIN = 15


class AIError(Exception):
    pass


def chosen_model_file():
    """The .gguf file of the model picked in Asystent AI (or the first one there)."""
    try:
        cfg = json.load(open(CFG))
    except (OSError, ValueError):
        cfg = {}
    files = sorted(f for f in os.listdir(MODELS) if f.endswith(".gguf")) if os.path.isdir(MODELS) else []
    want = cfg.get("model_file")
    if want in files:
        return os.path.join(MODELS, want)
    if files:
        return os.path.join(MODELS, files[0])
    return None


def _alive(st):
    try:
        os.kill(st["pid"], 0)
    except (OSError, KeyError, TypeError):
        return False
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{st['port']}/health", timeout=2) as r:
            return r.status == 200
    except Exception:
        return None                   # running, still loading


def touch():
    try:
        with open(USED, "w") as f:
            f.write(str(time.time()))
    except OSError:
        pass


def stop():
    try:
        st = json.load(open(STATE))
        os.killpg(st["pid"], signal.SIGTERM)
    except (OSError, ValueError, KeyError):
        pass
    for p in (STATE, USED):
        try:
            os.remove(p)
        except OSError:
            pass


def ensure(model_file=None, wait=180):
    """Start the server if needed (with model_file or the chosen model);
    -> port. Raises AIError."""
    model_file = model_file or chosen_model_file()
    if not model_file:
        raise AIError("Nie pobrano jeszcze żadnego modelu AI – otwórz Asystenta AI i wybierz model.")
    try:
        st = json.load(open(STATE))
    except (OSError, ValueError):
        st = None
    if st and st.get("model") == model_file:
        ok = _alive(st)
        if ok is not False:
            return _wait_ready(st, wait)
    if st:
        stop()
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    threads = max(2, (os.cpu_count() or 4) - 1)
    os.makedirs(DATA, exist_ok=True)
    log = open(os.path.join(DATA, "server.log"), "w")
    p = subprocess.Popen([SERVER, "-m", model_file, "--host", "127.0.0.1", "--port", str(port),
                          "-c", "4096", "-t", str(threads), "--jinja", "--no-webui"],
                         stdout=log, stderr=log, stdin=subprocess.DEVNULL, start_new_session=True)
    st = {"pid": p.pid, "port": port, "model": model_file}
    with open(STATE, "w") as f:
        json.dump(st, f)
    touch()
    # the watchdog (a detached copy of this module) stops an idle server
    subprocess.Popen([sys.executable, os.path.abspath(__file__), "--watch", str(p.pid)],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                     start_new_session=True)
    return _wait_ready(st, wait)


def _wait_ready(st, wait):
    t0 = time.time()
    while time.time() - t0 < wait:
        ok = _alive(st)
        if ok:
            touch()
            return st["port"]
        if ok is False:
            raise AIError("Silnik AI nie działa – może za mało pamięci RAM dla tego modelu "
                          "(szczegóły: ~/.local/share/glassos-ai/server.log).")
        time.sleep(0.5)
    raise AIError("Silnik AI nie wystartował na czas.")


def stream(messages, port=None, max_tokens=1500, temperature=0.6, stop_flag=None):
    """Yield answer pieces (OpenAI-compatible streaming)."""
    port = port or ensure()
    touch()
    body = json.dumps({"messages": messages, "stream": True, "temperature": temperature,
                       "max_tokens": max_tokens}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{port}/v1/chat/completions", data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=900) as r:
        for raw in r:
            if stop_flag is not None and stop_flag.is_set():
                break
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                piece = json.loads(data)["choices"][0].get("delta", {}).get("content") or ""
            except (ValueError, KeyError, IndexError):
                continue
            if piece:
                touch()
                yield piece
    touch()


def _watch(pid):
    while True:
        time.sleep(30)
        try:
            os.kill(pid, 0)
        except OSError:
            return
        try:
            last = float(open(USED).read())
        except (OSError, ValueError):
            last = 0
        if time.time() - last > IDLE_MIN * 60:
            try:
                st = json.load(open(STATE))
                if st.get("pid") == pid:
                    stop()
                else:
                    os.killpg(pid, signal.SIGTERM)
            except (OSError, ValueError):
                try:
                    os.killpg(pid, signal.SIGTERM)
                except OSError:
                    pass
            return


if __name__ == "__main__" and sys.argv[1:2] == ["--watch"]:
    _watch(int(sys.argv[2]))
