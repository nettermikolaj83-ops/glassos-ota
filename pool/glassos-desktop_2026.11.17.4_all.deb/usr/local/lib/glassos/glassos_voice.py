"""GlassOS voice: speech to text (whisper.cpp) and text to speech (Piper).

Everything runs on this computer. The models are downloaded on first use
into ~/.local/share/glassos-ai: Whisper "small" (multilingual, q5_1, 190 MB,
MIT) and the Polish Piper voice "Gosia" (CC0, 63 MB).

Installed as /usr/local/lib/glassos/glassos_voice.py.
"""
import os
import re
import signal
import subprocess
import tempfile
import threading
import time
import urllib.request

DATA = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "glassos-ai")
WHISPER_BIN = "/usr/local/bin/glassos-whisper"
PIPER_BIN = "/usr/local/bin/glassos-piper"
WHISPER_MODEL = ("ggml-small-q5_1.bin", "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small-q5_1.bin",
                 190 * 1024 ** 2)
VOICE = "pl_PL-gosia-medium"
# pinned: newer revisions of the voice use phonemes this Piper build cannot read
VOICE_REV = "v1.0.0"
VOICE_URL = f"https://huggingface.co/rhasspy/piper-voices/resolve/{VOICE_REV}/pl/pl_PL/gosia/medium/"
VOICE_DIR = os.path.join("voices", VOICE_REV)


class VoiceError(Exception):
    pass


def _fetch(url, dest, on_progress=None, total_hint=0):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    part = dest + ".part"
    for attempt in range(5):
        have = os.path.getsize(part) if os.path.exists(part) else 0
        req = urllib.request.Request(url, headers={"User-Agent": "GlassOS-voice"})
        if have:
            req.add_header("Range", f"bytes={have}-")
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                if r.status != 206:
                    have = 0
                total = int(r.headers.get("Content-Length", 0)) + have or total_hint
                with open(part, "ab" if have else "wb") as f:
                    while True:
                        chunk = r.read(1 << 20)
                        if not chunk:
                            break
                        f.write(chunk)
                        have += len(chunk)
                        if on_progress and total:
                            on_progress(have / total)
            os.replace(part, dest)
            return dest
        except Exception:
            time.sleep(2 + attempt * 2)
    raise VoiceError("Nie udało się pobrać modelu mowy – sprawdź internet.")


def whisper_model(on_progress=None):
    path = os.path.join(DATA, "whisper", WHISPER_MODEL[0])
    if not os.path.exists(path):
        _fetch(WHISPER_MODEL[1], path, on_progress, WHISPER_MODEL[2])
    return path


def voice_model(on_progress=None):
    d = os.path.join(DATA, VOICE_DIR)
    onnx = os.path.join(d, VOICE + ".onnx")
    if not os.path.exists(onnx + ".json"):
        _fetch(VOICE_URL + VOICE + ".onnx.json", onnx + ".json")
    if not os.path.exists(onnx):
        _fetch(VOICE_URL + VOICE + ".onnx", onnx, on_progress, 63 * 1024 ** 2)
    return onnx


# ---------------------------------------------------------------- listening
class Recorder:
    """Records the default microphone into a 16 kHz mono WAV (parecord)."""

    def __init__(self):
        self.path = os.path.join(tempfile.gettempdir(), f"glassos-voice-{os.getpid()}.wav")
        self.proc = None

    def start(self):
        try:
            self.proc = subprocess.Popen(["parecord", "--file-format=wav", "--rate=16000", "--channels=1",
                                          "--format=s16le", self.path],
                                         stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except OSError as e:
            raise VoiceError(f"Nie można nagrywać dźwięku: {e}")
        time.sleep(0.3)
        if self.proc.poll() is not None:
            raise VoiceError("Brak mikrofonu albo dźwięk nie działa.")

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.send_signal(signal.SIGINT)
            try:
                self.proc.wait(3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        return self.path


def transcribe(wav, lang="pl"):
    model = whisper_model()
    threads = str(max(2, (os.cpu_count() or 4) - 1))
    try:
        p = subprocess.run([WHISPER_BIN, "-m", model, "-l", lang, "-nt", "-np", "-t", threads, "-f", wav],
                           capture_output=True, text=True, timeout=600)
    except (OSError, subprocess.SubprocessError) as e:
        raise VoiceError(f"Rozpoznawanie mowy nie działa: {e}")
    finally:
        try:
            os.remove(wav)
        except OSError:
            pass
    text = " ".join(l.strip() for l in p.stdout.splitlines() if l.strip())
    text = re.sub(r"\[(BLANK_AUDIO|MUSIC|Muzyka|muzyka)\]|\((muzyka|cisza)\)", "", text).strip()
    return text


# ---------------------------------------------------------------- speaking
class Speaker:
    """Reads text aloud sentence by sentence (Piper -> paplay); stop() cuts it."""

    def __init__(self):
        self.stop_flag = threading.Event()
        self.procs = []

    def stop(self):
        self.stop_flag.set()
        for p in self.procs:
            try:
                p.kill()
            except OSError:
                pass

    def say(self, text, on_done=None):
        self.stop_flag.clear()

        def work():
            err = None
            try:
                model = voice_model()
                clean = re.sub(r"[*#`_>|]+", " ", text)
                parts = [s.strip() for s in re.split(r"(?<=[.!?…:;])\s+|\n+", clean) if s.strip()]
                for s in parts:
                    if self.stop_flag.is_set():
                        break
                    wav = os.path.join(tempfile.gettempdir(), f"glassos-tts-{os.getpid()}.wav")
                    p = subprocess.Popen([PIPER_BIN, "--model", model, "--output_file", wav],
                                         stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL)
                    self.procs = [p]
                    p.communicate(s.encode())
                    if self.stop_flag.is_set():
                        break
                    q = subprocess.Popen(["paplay", wav], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    self.procs = [q]
                    q.wait()
            except Exception as e:
                err = str(e)
            if on_done:
                on_done(err)
        threading.Thread(target=work, daemon=True).start()
