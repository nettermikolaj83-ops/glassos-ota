"""GlassOS calendar data: events, repeats, Polish public holidays, .ics.

Events live in ~/.local/share/glassos/calendar.json:
  {"events": [{"id", "title", "start": "YYYY-MM-DDTHH:MM", "end": ..., "allday": bool,
               "remind": minutes before or null, "repeat": none|daily|weekly|monthly|yearly,
               "color": "#rrggbb", "notes": ""}]}
Used by Kalendarz, glassos-reminderd (reminders), the lock screen and the bar.
Installed as /usr/local/lib/glassos/glassos_calendar.py.
"""
import calendar as _cal
import datetime as dt
import json
import os
import re
import uuid

DATA = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "glassos")
FILE = os.path.join(DATA, "calendar.json")
COLORS = ["#5b8cff", "#e5484d", "#30a46c", "#f5a524", "#8e4ec6", "#12a594", "#d6409f"]
MONTHS = ["styczeń", "luty", "marzec", "kwiecień", "maj", "czerwiec", "lipiec", "sierpień", "wrzesień",
          "październik", "listopad", "grudzień"]
MONTHS_GEN = ["stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca", "lipca", "sierpnia", "września",
              "października", "listopada", "grudnia"]
DAYS = ["poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela"]
DAYS_SHORT = ["pon", "wto", "śro", "czw", "pią", "sob", "nie"]
REPEATS = [("none", "Nie powtarzaj"), ("daily", "Codziennie"), ("weekly", "Co tydzień"),
           ("monthly", "Co miesiąc"), ("yearly", "Co roku")]


# ------------------------------------------------------------ storage
def load():
    try:
        with open(FILE, encoding="utf-8") as f:
            data = json.load(f)
        return [e for e in data.get("events", []) if e.get("start")]
    except (OSError, ValueError):
        return []


def save(events):
    os.makedirs(DATA, exist_ok=True)
    with open(FILE + ".tmp", "w", encoding="utf-8") as f:
        json.dump({"events": events}, f, ensure_ascii=False, indent=1)
    os.replace(FILE + ".tmp", FILE)


def new_event(title, start, end=None, allday=False, remind=15, repeat="none", color=None, notes=""):
    if end is None:
        end = start + (dt.timedelta(days=1) if allday else dt.timedelta(hours=1))
    return {"id": uuid.uuid4().hex[:12], "title": title, "start": start.strftime("%Y-%m-%dT%H:%M"),
            "end": end.strftime("%Y-%m-%dT%H:%M"), "allday": allday, "remind": remind, "repeat": repeat,
            "color": color or COLORS[0], "notes": notes}


def parse(s):
    return dt.datetime.strptime(s[:16], "%Y-%m-%dT%H:%M")


# ------------------------------------------------------------ repeats
def _add_months(d, n):
    m = d.month - 1 + n
    y = d.year + m // 12
    m = m % 12 + 1
    day = min(d.day, _cal.monthrange(y, m)[1])
    return d.replace(year=y, month=m, day=day)


def occurrences(events, start, end):
    """-> sorted list of (begin, finish, event) overlapping [start, end) (datetimes)."""
    out = []
    for e in events:
        try:
            b, f = parse(e["start"]), parse(e["end"])
        except (KeyError, ValueError):
            continue
        dur = max(f - b, dt.timedelta(0))
        rep = e.get("repeat", "none")
        if rep == "none":
            if b < end and b + dur >= start and (b + dur > start or dur == dt.timedelta(0)):
                out.append((b, b + dur, e))
            continue
        # jump close to the window, then walk
        cur, n = b, 0
        if rep == "daily" and b < start:
            n = max(0, (start - b).days - 1)
            cur = b + dt.timedelta(days=n)
        elif rep == "weekly" and b < start:
            n = max(0, (start - b).days // 7 - 1)
            cur = b + dt.timedelta(weeks=n)
        elif rep == "monthly" and b < start:
            n = max(0, (start.year - b.year) * 12 + start.month - b.month - 1)
            cur = _add_months(b, n)
        elif rep == "yearly" and b < start:
            n = max(0, start.year - b.year - 1)
            cur = _add_months(b, 12 * n)
        guard = 0
        while cur < end and guard < 1000:
            if cur + dur > start or (dur == dt.timedelta(0) and cur >= start):
                out.append((cur, cur + dur, e))
            n += 1
            guard += 1
            cur = (b + dt.timedelta(days=n) if rep == "daily" else b + dt.timedelta(weeks=n) if rep == "weekly"
                   else _add_months(b, n) if rep == "monthly" else _add_months(b, 12 * n))
    out.sort(key=lambda x: (not x[2].get("allday"), x[0]))
    return out


def on_day(events, day):
    d0 = dt.datetime(day.year, day.month, day.day)
    return occurrences(events, d0, d0 + dt.timedelta(days=1))


# ------------------------------------------------------------ Polish holidays
def _easter(y):
    a, b, c = y % 19, y // 100, y % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = (h + l - 7 * m + 114) % 31 + 1
    return dt.date(y, month, day)


def holidays(year):
    """-> {date: name} public holidays in Poland (days off)."""
    e = _easter(year)
    h = {
        dt.date(year, 1, 1): "Nowy Rok", dt.date(year, 1, 6): "Trzech Króli",
        e: "Wielkanoc", e + dt.timedelta(days=1): "Poniedziałek Wielkanocny",
        dt.date(year, 5, 1): "Święto Pracy", dt.date(year, 5, 3): "Święto Konstytucji 3 Maja",
        e + dt.timedelta(days=49): "Zielone Świątki", e + dt.timedelta(days=60): "Boże Ciało",
        dt.date(year, 8, 15): "Wniebowzięcie NMP", dt.date(year, 11, 1): "Wszystkich Świętych",
        dt.date(year, 11, 11): "Święto Niepodległości",
        dt.date(year, 12, 25): "Boże Narodzenie", dt.date(year, 12, 26): "Drugi dzień Bożego Narodzenia",
    }
    if year >= 2025:
        h[dt.date(year, 12, 24)] = "Wigilia"
    return h


# ------------------------------------------------------------ .ics
def _ics_unfold(text):
    return re.sub(r"\r?\n[ \t]", "", text).splitlines()


def _ics_unescape(v):
    return v.replace("\\n", "\n").replace("\\N", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")


def _ics_time(v):
    v = v.strip()
    if re.fullmatch(r"\d{8}", v):
        return dt.datetime.strptime(v, "%Y%m%d"), True
    utc = v.endswith("Z")
    t = dt.datetime.strptime(v.rstrip("Z")[:15], "%Y%m%dT%H%M%S")
    if utc:
        t = t.replace(tzinfo=dt.timezone.utc).astimezone().replace(tzinfo=None)
    return t, False


def import_ics(path):
    """-> list of new events from an .ics file."""
    with open(path, encoding="utf-8", errors="replace") as f:
        lines = _ics_unfold(f.read())
    out, cur = [], None
    for line in lines:
        if line == "BEGIN:VEVENT":
            cur = {}
        elif line == "END:VEVENT" and cur is not None:
            if "DTSTART" in cur:
                b, allday = cur["DTSTART"]
                f = cur.get("DTEND", (b + (dt.timedelta(days=1) if allday else dt.timedelta(hours=1)), allday))[0]
                rep = {"DAILY": "daily", "WEEKLY": "weekly", "MONTHLY": "monthly", "YEARLY": "yearly"}.get(
                    cur.get("FREQ", ""), "none")
                out.append(new_event(cur.get("SUMMARY", "Wydarzenie"), b, f, allday,
                                     None if allday else 15, rep, notes=cur.get("DESCRIPTION", "")))
            cur = None
        elif cur is not None and ":" in line:
            key, val = line.split(":", 1)
            name = key.split(";", 1)[0].upper()
            if name in ("DTSTART", "DTEND"):
                try:
                    cur[name] = _ics_time(val)
                except ValueError:
                    pass
            elif name in ("SUMMARY", "DESCRIPTION"):
                cur[name] = _ics_unescape(val)
            elif name == "RRULE":
                m = re.search(r"FREQ=(\w+)", val)
                if m:
                    cur["FREQ"] = m.group(1)
    return out


def export_ics(events, path):
    def esc(s):
        return s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
    rows = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//GlassOS//Kalendarz//PL"]
    for e in events:
        b, f = parse(e["start"]), parse(e["end"])
        rows.append("BEGIN:VEVENT")
        rows.append(f"UID:{e['id']}@glassos")
        if e.get("allday"):
            rows += [f"DTSTART;VALUE=DATE:{b:%Y%m%d}", f"DTEND;VALUE=DATE:{f:%Y%m%d}"]
        else:
            rows += [f"DTSTART:{b:%Y%m%dT%H%M%S}", f"DTEND:{f:%Y%m%dT%H%M%S}"]
        rows.append("SUMMARY:" + esc(e.get("title", "")))
        if e.get("notes"):
            rows.append("DESCRIPTION:" + esc(e["notes"]))
        if e.get("repeat", "none") != "none":
            rows.append("RRULE:FREQ=" + e["repeat"].upper())
        rows.append("END:VEVENT")
    rows.append("END:VCALENDAR")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(rows) + "\n")


def describe_time(b, f, allday):
    if allday:
        return "Cały dzień"
    return f"{b:%H:%M} – {f:%H:%M}"
