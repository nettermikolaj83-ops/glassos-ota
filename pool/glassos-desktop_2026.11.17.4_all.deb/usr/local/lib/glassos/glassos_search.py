"""GlassOS: search inside files (Spotlight "W treści", "?? question").

glassos-indexer keeps ~/.cache/glassos-search/index.db up to date: the text
of documents in Dokumenty, Pulpit, Pobrane (and Obrazy' text files) in an
SQLite FTS5 table that ignores Polish letters (zolw finds żółw).
Installed as /usr/local/lib/glassos/glassos_search.py.
"""
import os
import re
import sqlite3
import subprocess
import time
import zipfile

CACHE = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"), "glassos-search")
DB = os.path.join(CACHE, "index.db")
MAX_BYTES = 30 * 1024 * 1024
MAX_CHARS = 300_000
TEXT_EXT = (".txt", ".md", ".csv", ".tsv", ".json", ".xml", ".html", ".htm", ".py", ".sh", ".c", ".h", ".js",
            ".ts", ".css", ".ini", ".conf", ".log", ".tex", ".srt", ".yaml", ".yml", ".rst", ".java", ".rs", ".go")
DOC_EXT = (".pdf", ".docx", ".odt", ".ods", ".odp", ".pptx", ".xlsx", ".rtf", ".epub")
STOP = set("a aby ale ani bo by być był była było co czy dla do i ich ile im jak jaka jaki jakie jest jestem "
           "już ktora która które który mam mi mnie mój moja moje na nad nie o od po pod przez przy się są ta "
           "tak te ten to tu w we z za ze że gdzie kiedy jaką jakim mój moim moich mojej the of and or is in to "
           "what where when how".split())


def user_dirs():
    out = []
    try:
        from gi.repository import GLib
        for d in (GLib.UserDirectory.DIRECTORY_DOCUMENTS, GLib.UserDirectory.DIRECTORY_DESKTOP,
                  GLib.UserDirectory.DIRECTORY_DOWNLOAD):
            p = GLib.get_user_special_dir(d)
            if p and p != os.path.expanduser("~") and os.path.isdir(p):
                out.append(p)
    except Exception:          # noqa: BLE001
        pass
    for p in ("~/Dokumenty", "~/Pulpit", "~/Pobrane"):
        p = os.path.expanduser(p)
        if os.path.isdir(p) and p not in out:
            out.append(p)
    return out


# ------------------------------------------------------------ text out of files
def _xml_text(data):
    data = re.sub(rb"<(w:p|text:p|a:p|text:h)[ >]", b"\n<\\1 ", data)
    data = re.sub(rb"<[^>]+>", b" ", data)
    t = data.decode("utf-8", "replace")
    for a, b in (("&lt;", "<"), ("&gt;", ">"), ("&amp;", "&"), ("&quot;", '"'), ("&apos;", "'")):
        t = t.replace(a, b)
    return re.sub(r"[ \t]+", " ", t)


def extract(path):
    low = path.lower()
    try:
        if low.endswith(".pdf"):
            r = subprocess.run(["pdftotext", "-q", "-enc", "UTF-8", "-l", "60", path, "-"],
                               capture_output=True, timeout=60)
            return r.stdout.decode("utf-8", "replace")[:MAX_CHARS]
        if low.endswith((".docx", ".pptx", ".xlsx", ".odt", ".ods", ".odp", ".epub")):
            out = []
            with zipfile.ZipFile(path) as z:
                for n in z.namelist():
                    if (n in ("word/document.xml", "content.xml") or n.startswith(("ppt/slides/slide", "xl/sharedStrings"))
                            or (low.endswith(".epub") and n.endswith((".xhtml", ".html")))):
                        out.append(_xml_text(z.read(n)))
                    if sum(map(len, out)) > MAX_CHARS:
                        break
            return "\n".join(out)[:MAX_CHARS]
        if low.endswith(".rtf"):
            raw = open(path, "rb").read(MAX_BYTES).decode("latin-1", "replace")
            return re.sub(r"\\[a-z]+-?\d* ?|[{}]", " ", raw)[:MAX_CHARS]
        if low.endswith(TEXT_EXT):
            with open(path, "rb") as f:
                raw = f.read(MAX_CHARS * 2)
            if b"\0" in raw[:4096]:
                return ""
            t = raw.decode("utf-8", "replace")
            if low.endswith((".html", ".htm", ".xml")):
                t = re.sub(r"<[^>]+>", " ", t)
            return t[:MAX_CHARS]
    except (OSError, zipfile.BadZipFile, subprocess.SubprocessError, KeyError):
        return ""
    return ""


# ------------------------------------------------------------ the index
def connect():
    os.makedirs(CACHE, exist_ok=True)
    db = sqlite3.connect(DB, timeout=10)
    db.execute("CREATE TABLE IF NOT EXISTS files (path TEXT PRIMARY KEY, mtime REAL)")
    # "fold": name + body with ł -> l (the tokenizer drops ąęóż… accents but ł is a letter of its own)
    db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS docs USING fts5(path UNINDEXED, name, body, fold, "
               "tokenize='unicode61 remove_diacritics 2')")
    return db


def update(dirs=None, budget_s=None):
    """Index new and changed files, drop deleted ones. -> number indexed."""
    db = connect()
    known = dict(db.execute("SELECT path, mtime FROM files"))
    seen = set()
    n = 0
    t0 = time.time()
    for top in dirs or user_dirs():
        for root, ds, fs in os.walk(top):
            ds[:] = [d for d in ds if not d.startswith(".") and d not in ("node_modules", "__pycache__", "venv")]
            for name in fs:
                low = name.lower()
                if name.startswith(".") or not low.endswith(TEXT_EXT + DOC_EXT):
                    continue
                p = os.path.join(root, name)
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                if st.st_size > MAX_BYTES:
                    continue
                seen.add(p)
                if known.get(p) == st.st_mtime:
                    continue
                body = extract(p)
                db.execute("DELETE FROM docs WHERE path = ?", (p,))
                db.execute("INSERT INTO docs (path, name, body, fold) VALUES (?, ?, ?, ?)",
                           (p, name, body, fold(name + "\n" + body)))
                db.execute("INSERT OR REPLACE INTO files VALUES (?, ?)", (p, st.st_mtime))
                n += 1
                if n % 50 == 0:
                    db.commit()
                if budget_s and time.time() - t0 > budget_s:
                    db.commit()
                    return n
    for p in set(known) - seen:
        db.execute("DELETE FROM docs WHERE path = ?", (p,))
        db.execute("DELETE FROM files WHERE path = ?", (p,))
    db.commit()
    db.close()
    return n


def fold(t):
    return t.replace("ł", "l").replace("Ł", "L")


def _terms(text, stem=False):
    words = re.findall(r"\w+", fold(text.lower()))
    out = []
    for w in words:
        if stem:
            if w in STOP or len(w) < 3:
                continue
            w = w[:max(4, len(w) - 2)] if len(w) > 5 else w     # crude Polish stemming: endings vary
        out.append('"' + w.replace('"', "") + '"*')
    return out


def search(text, limit=5, any_word=False, stem=False):
    """-> [(path, name, snippet)] best first."""
    if not os.path.exists(DB):
        return []
    terms = _terms(text, stem)
    if not terms:
        return []
    q = (" OR " if any_word else " ").join(terms)
    try:
        db = sqlite3.connect(DB, timeout=2)
        rows = db.execute("SELECT path, name, snippet(docs, 2, '«', '»', '…', 14) FROM docs WHERE docs MATCH ? "
                          "ORDER BY bm25(docs, 0, 4.0, 1.0, 0.8) LIMIT ?", (q, limit * 3)).fetchall()
        db.close()
    except sqlite3.Error:
        return []
    return [r for r in rows if os.path.exists(r[0])][:limit]


def passages(path, question, chars=2400):
    """The parts of a document that best fit the question (for the AI)."""
    text = extract(path)
    if len(text) <= chars:
        return text
    words = {w[:max(4, len(w) - 2)] for w in re.findall(r"\w+", question.lower()) if w not in STOP and len(w) > 2}
    paras = [p.strip() for p in re.split(r"\n\s*\n|\n", text) if p.strip()]
    scored = []
    for i, p in enumerate(paras):
        low = p.lower()
        scored.append((sum(low.count(w) for w in words), i))
    scored.sort(reverse=True)
    keep, size = set(), 0
    for s, i in scored:
        if size > chars:
            break
        for j in (i - 1, i, i + 1):
            if 0 <= j < len(paras) and j not in keep:
                keep.add(j)
                size += len(paras[j])
    return "\n".join(paras[i] for i in sorted(keep))[:chars]
