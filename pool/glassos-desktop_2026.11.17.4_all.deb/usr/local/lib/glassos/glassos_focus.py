"""GlassOS Tryb skupienia (focus): while it is on, notifications are not
shown (they wait in the notification center), except from the apps on the
"allowed" list and urgent ones (alarms, timers). It is turned on by hand
(Super+Shift+F, notification center, Settings) or by a schedule.

settings.ini keys: focus_on, focus_sched, focus_from, focus_to, focus_days
(0 = Monday ... 6), focus_allow (app names, comma separated).
Installed as /usr/local/lib/glassos/glassos_focus.py.
"""
import datetime as dt
import os

CFG = os.path.expanduser("~/.config/glassos/settings.ini")
DEFAULT_ALLOW = "Zegar,Kalendarz,Budzik,Minutnik,Telefon,KDE Connect"


def settings():
    out = {}
    try:
        with open(CFG, encoding="utf-8") as f:
            for line in f:
                if "=" in line:
                    k, v = line.split("=", 1)
                    out[k.strip()] = v.strip()
    except OSError:
        pass
    return out


def _minutes(hhmm):
    try:
        h, m = hhmm.split(":")
        return int(h) * 60 + int(m)
    except ValueError:
        return 0


def scheduled(s=None, now=None):
    """Is it inside the schedule now? (a range over midnight belongs to the day it starts)"""
    s = s if s is not None else settings()
    if s.get("focus_sched", "0") != "1":
        return False
    now = now or dt.datetime.now()
    a, b = _minutes(s.get("focus_from", "22:00")), _minutes(s.get("focus_to", "07:00"))
    days = {int(x) for x in s.get("focus_days", "0,1,2,3,4,5,6").split(",") if x.strip().isdigit()}
    t = now.hour * 60 + now.minute
    if a == b:
        return False
    if a < b:
        return a <= t < b and now.weekday() in days
    if t >= a:                                   # evening part
        return now.weekday() in days
    if t < b:                                    # morning part: started yesterday
        return (now.weekday() - 1) % 7 in days
    return False


def active(s=None):
    s = s if s is not None else settings()
    return s.get("focus_on", "0") == "1" or scheduled(s)


def allowed_apps(s=None):
    s = s if s is not None else settings()
    return [x.strip() for x in s.get("focus_allow", DEFAULT_ALLOW).split(",") if x.strip()]


def blocks(app, urgency=1, s=None):
    """Should a notification from app be held back now?"""
    s = s if s is not None else settings()
    if urgency == 2 or not active(s):
        return False
    low = (app or "").lower()
    return not any(a.lower() == low or (a and a.lower() in low) for a in allowed_apps(s))
