"""GlassOS keyboard shortcuts: the actions, their default keys and the
conversion to Wayfire's syntax. Keys are stored in Openbox-like notation
("W-S-4" = Super+Shift+4), which ~/.config/glassos/shortcuts.ini and
Settings > Skróty klawiszowe use.

Installed as /usr/local/lib/glassos/glassos_keys.py.
"""

# id, label, how: ("exec", command) | ("wf", "section/option") | ("wfcmd", ipc-free command)
ACTIONS = [
    ("spotlight", "Spotlight (wyszukiwanie)", ("exec", "glassos-spotlight")),
    ("launchpad", "Launchpad", ("exec", "launchpad")),
    ("emoji", "Emoji", ("exec", "glassos-emoji")),
    ("switch-next", "Przełącz okno", ("wf", "fast-switcher/activate")),
    ("switch-prev", "Przełącz okno wstecz", ("wf", "fast-switcher/activate_backward")),
    ("expose", "Wszystkie okna (Mission Control)", ("wf", "scale/toggle")),
    ("desktops", "Wszystkie biurka", ("wf", "expo/toggle")),
    ("notifications", "Centrum powiadomień", ("exec", "glassos-notifyd --toggle")),
    ("lock", "Zablokuj ekran", ("exec", "glassos-lock")),
    ("shot-full", "Zrzut całego ekranu", ("exec", "glassos-screenshot full")),
    ("shot-area", "Zrzut zaznaczonego obszaru", ("exec", "glassos-screenshot area")),
    ("shot-window", "Zrzut okna", ("exec", "glassos-screenshot window")),
    ("snap-left", "Okno na lewą połowę", ("wf", "grid/slot_l")),
    ("snap-right", "Okno na prawą połowę", ("wf", "grid/slot_r")),
    ("snap-max", "Maksymalizuj okno", ("wf", "grid/slot_c")),
    ("snap-restore", "Przywróć rozmiar okna", ("wf", "grid/restore")),
    ("snap-tl", "Okno w lewą górną ćwiartkę", ("wf", "grid/slot_tl")),
    ("snap-tr", "Okno w prawą górną ćwiartkę", ("wf", "grid/slot_tr")),
    ("snap-bl", "Okno w lewą dolną ćwiartkę", ("wf", "grid/slot_bl")),
    ("snap-br", "Okno w prawą dolną ćwiartkę", ("wf", "grid/slot_br")),
    ("record", "Nagrywanie ekranu (start/stop)", ("exec", "glassos-record toggle")),
    ("record-area", "Nagrywanie zaznaczonego obszaru", ("exec", "glassos-record area")),
    ("activity", "Monitor aktywności", ("exec", "glassos-activity")),
    ("files", "Pliki (menedżer plików)", ("exec", "thunar")),
    ("terminal", "Terminal", ("exec", "xterm")),
    ("settings", "Ustawienia", ("exec", "glassos-settings")),
    ("show-desktop", "Pokaż pulpit", ("wf", "wm-actions/toggle_showdesktop")),
    ("close", "Zamknij okno", ("wf", "core/close_top_view")),
    ("desk-left", "Biurko w lewo", ("wf", "vswitch/binding_left")),
    ("desk-right", "Biurko w prawo", ("wf", "vswitch/binding_right")),
    ("move-left", "Przenieś okno na biurko w lewo", ("wf", "vswitch/with_win_left")),
    ("move-right", "Przenieś okno na biurko w prawo", ("wf", "vswitch/with_win_right")),
]
LABELS = {a[0]: a[1] for a in ACTIONS}
HOW = {a[0]: a[2] for a in ACTIONS}

DEFAULTS = {
    "spotlight": ["W-space"], "launchpad": [], "emoji": ["W-period"],
    "switch-next": ["A-Tab"], "switch-prev": ["A-S-Tab"], "expose": ["W-Tab"],
    "desktops": ["W-e"], "notifications": ["W-n"], "lock": ["W-l", "C-W-q"],
    "shot-full": ["Print", "W-S-3"], "shot-area": ["S-Print", "W-S-4"], "shot-window": ["A-Print", "W-S-5"],
    "snap-left": ["W-Left"], "snap-right": ["W-Right"], "snap-max": ["W-Up"], "snap-restore": ["W-Down"],
    "snap-tl": ["C-W-Left"], "snap-tr": ["C-W-Right"], "snap-bl": ["C-S-W-Left"], "snap-br": ["C-S-W-Right"],
    "record": ["W-S-r"], "record-area": ["W-S-6"], "activity": ["C-S-Escape"], "files": ["W-f"],
    "terminal": ["C-A-t"], "settings": ["W-comma"], "show-desktop": ["W-d"], "close": ["A-F4"],
    "desk-left": ["C-A-Left"], "desk-right": ["C-A-Right"],
    "move-left": ["S-A-Left"], "move-right": ["S-A-Right"],
}

MOD_NAMES = {"W": "Super", "C": "Ctrl", "A": "Alt", "S": "Shift", "M": "Meta", "H": "Hyper"}
KEY_NAMES = {"space": "Spacja", "Tab": "Tab", "Left": "←", "Right": "→", "Up": "↑", "Down": "↓",
             "Return": "Enter", "Escape": "Esc", "Print": "Print Screen", "BackSpace": "Backspace",
             "Delete": "Delete", "Home": "Home", "End": "End", "Prior": "PgUp", "Next": "PgDn",
             "period": ".", "comma": ","}
WF_MODS = {"W": "<super>", "C": "<ctrl>", "A": "<alt>", "S": "<shift>"}
WF_KEYS = {"space": "SPACE", "Tab": "TAB", "Left": "LEFT", "Right": "RIGHT", "Up": "UP", "Down": "DOWN",
           "Return": "ENTER", "Escape": "ESC", "Print": "SYSRQ", "BackSpace": "BACKSPACE",
           "Delete": "DELETE", "Home": "HOME", "End": "END", "Prior": "PAGEUP", "Next": "PAGEDOWN",
           "period": "DOT", "comma": "COMMA", "minus": "MINUS", "-": "MINUS", "equal": "EQUAL",
           "slash": "SLASH", "grave": "GRAVE", "Insert": "INSERT"}


def split(key):
    parts = key.split("-")
    if len(parts) > 1 and parts[-1] == "":         # key named "-" (minus)
        parts = parts[:-2] + ["-"]
    return parts[:-1], parts[-1]


def pretty(key):
    """'W-S-4' -> 'Super+Shift+4'."""
    mods, k = split(key)
    k = KEY_NAMES.get(k, k.upper() if len(k) == 1 else k)
    return "+".join([MOD_NAMES.get(m, m) for m in mods] + [k])


def to_wayfire(key):
    """'W-S-4' -> '<super> <shift> KEY_4'."""
    mods, k = split(key)
    name = WF_KEYS.get(k)
    if not name:
        name = k.upper() if len(k) == 1 else k.upper()
    return " ".join([WF_MODS[m] for m in mods if m in WF_MODS] + ["KEY_" + name])
