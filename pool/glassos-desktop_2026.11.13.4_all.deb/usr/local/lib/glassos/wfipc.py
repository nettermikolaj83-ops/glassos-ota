"""GlassOS: talk to the Wayfire compositor over its IPC socket.

Messages are JSON with a 4-byte little-endian length in front. Requests are
{"method": ..., "data": {...}}; after "window-rules/events/watch" the
connection streams events ({"event": "view-focused", "view": {...}}).

Installed as /usr/local/lib/glassos/wfipc.py; scripts do
    sys.path.insert(0, "/usr/local/lib/glassos"); import wfipc
"""
import glob
import json
import os
import socket
import struct


class WFError(Exception):
    pass


def socket_path():
    p = os.environ.get("WAYFIRE_SOCKET")
    if p and os.path.exists(p):
        return p
    disp = os.environ.get("WAYLAND_DISPLAY", "wayland-1")
    p = f"/tmp/wayfire-{disp}.socket"
    if os.path.exists(p):
        return p
    mine = [q for q in glob.glob("/tmp/wayfire-*.socket") if os.stat(q).st_uid == os.getuid()]
    if mine:
        return max(mine, key=os.path.getmtime)
    raise WFError("Wayfire IPC socket not found")


class Conn:
    def __init__(self, path=None, timeout=5):
        self.s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        if timeout:
            self.s.settimeout(timeout)
        self.s.connect(path or socket_path())

    def close(self):
        try:
            self.s.close()
        except OSError:
            pass

    def _read(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.s.recv(n - len(buf))
            if not chunk:
                raise WFError("Wayfire closed the connection")
            buf += chunk
        return buf

    def send(self, method, data=None):
        msg = json.dumps({"method": method, "data": data or {}}).encode()
        self.s.sendall(struct.pack("<I", len(msg)) + msg)

    def recv(self):
        n = struct.unpack("<I", self._read(4))[0]
        return json.loads(self._read(n).decode("utf-8", "replace"))

    def call(self, method, **data):
        self.send(method, data)
        while True:
            r = self.recv()
            if "event" not in r:                 # skip events on a watch connection
                break
        if isinstance(r, dict) and r.get("result") == "error":
            raise WFError(r.get("error", "error"))
        return r


def call(method, **data):
    c = Conn()
    try:
        return c.call(method, **data)
    finally:
        c.close()


def watch():
    """Yield Wayfire events forever (raises WFError when Wayfire goes away)."""
    c = Conn(timeout=None)
    c.call("window-rules/events/watch")
    while True:
        yield c.recv()


# ------------------------------------------------------------ helpers
def views():
    r = call("window-rules/list-views")
    return r if isinstance(r, list) else r.get("views", [])


def app_views():
    """Ordinary app windows (no panels, desktop, our own shell)."""
    return [v for v in views() if is_app(v)]


def is_app(v):
    return bool(v) and v.get("role") == "toplevel" and v.get("mapped", True) \
        and v.get("type", "toplevel") == "toplevel"


def focused():
    try:
        v = call("window-rules/get-focused-view").get("info")
    except WFError:
        return None
    return v if is_app(v) else None


def focus(vid):
    return call("window-rules/focus-view", id=int(vid))


def close(vid):
    return call("window-rules/close-view", id=int(vid))


def minimize(vid, state=True):
    return call("wm-actions/set-minimized", view_id=int(vid), state=bool(state))


def toggle_maximize(vid):
    return call("wm-actions/toggle_maximize", view_id=int(vid))


def set_fullscreen(vid, state=True):
    return call("wm-actions/set-fullscreen", view_id=int(vid), state=bool(state))


def show_desktop():
    return call("wm-actions/toggle_showdesktop")


def scale_toggle():
    return call("scale/toggle")


def set_option(name, value):
    """Runtime option change, e.g. set_option("input/natural_scroll", True)."""
    return call("wayfire/set-config-options", **{name: value})


def outputs():
    r = call("window-rules/list-outputs")
    return r if isinstance(r, list) else r.get("outputs", [])


def activate_app(app_id):
    """Dock click: focus the app's newest window (unminimize it), or minimize
    them all when it is already focused (macOS-like). -> True if it had windows."""
    mine = [v for v in app_views() if v.get("app-id") == app_id]
    if not mine:
        return False
    f = focused()
    if f and f.get("app-id") == app_id and not f.get("minimized"):
        for v in mine:
            minimize(v["id"], True)
        return True
    for v in mine:
        if v.get("minimized"):
            minimize(v["id"], False)
    target = max(mine, key=lambda v: v.get("last-focus-timestamp", 0))
    focus(target["id"])
    return True


def main_output():
    """The main monitor (Settings -> Monitory, ~/.config/glassos/main-monitor)
    as Wayfire describes it: {"name", "geometry": {x, y, width, height}, ...}."""
    try:
        want = open(os.path.expanduser("~/.config/glassos/main-monitor")).read().strip()
    except OSError:
        want = ""
    try:
        outs = outputs()
    except (WFError, OSError):
        return None
    return next((o for o in outs if o.get("name") == want), outs[0] if outs else None)


def gdk_main_monitor(display):
    """GdkMonitor of the main monitor (matched by geometry: GTK 3 on Wayland
    does not know connector names)."""
    o = main_output()
    if o:
        g = o.get("geometry", {})
        for i in range(display.get_n_monitors()):
            m = display.get_monitor(i)
            r = m.get_geometry()
            if (r.x, r.y, r.width, r.height) == (g.get("x"), g.get("y"), g.get("width"), g.get("height")):
                return m
    return display.get_primary_monitor() or display.get_monitor(0)

