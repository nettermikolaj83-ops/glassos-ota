"""GlassOS on-screen keyboard widget (GTK3), shared by glassos-osk (desktop)
and glassos-tv (Tryb TV). It only builds the keys; what a key does is the
`on_key(kind, value)` callback: kind is "char" (value = text to type) or
"key" (value = BackSpace, Return, Tab, Left, Right, Up, Down, Escape, Hide).

Installed as /usr/local/lib/glassos/glassos_osk.py.
"""
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

CSS = b"""
.osk { background-color: rgba(18, 14, 40, 0.94); border-radius: 22px; padding: 12px;
       border: 1px solid rgba(255,255,255,0.14); }
.osk button { background-image: none; background-color: rgba(255,255,255,0.10); border: none; box-shadow: none;
              border-radius: 10px; color: #ffffff; font-size: 17px; min-height: 44px; min-width: 40px; padding: 0 6px; }
.osk button:hover, .osk button:focus { background-color: rgba(255,255,255,0.22); }
.osk button:active { background-color: rgba(255,255,255,0.34); }
.osk button.special { background-color: rgba(255,255,255,0.05); font-size: 14px; }
.osk button.on { background-color: #b05e76; }
.osk button.accent { background-color: #b05e76; }
.osk label { color: #ffffff; }
"""

LETTERS = [list("1234567890"), list("qwertyuiop"), list("asdfghjkl"), list("zxcvbnm,.")]
PL = list("ąćęłńóśźż")
SYMBOLS = [list("1234567890"), list("@#$%&*-+=/"), list("()[]{}<>:;"), list("_\"'!?~^|\\")]


class Keyboard(Gtk.Box):
    def __init__(self, on_key, polish=True):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        css = Gtk.CssProvider()
        css.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
        self.get_style_context().add_class("osk")
        self.on_key = on_key
        self.polish = polish
        self.shift = False
        self.caps = False
        self.symbols = False
        self.rows_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.pack_start(self.rows_box, True, True, 0)
        self.chars = []                      # (button, lower, upper) to relabel on shift
        self.build()

    # ---------------------------------------------------- building
    def btn(self, label, cb, cls=None, width=None):
        b = Gtk.Button(label=label)
        b.set_can_focus(True)
        if cls:
            b.get_style_context().add_class(cls)
        if width:
            b.set_size_request(width, -1)
        b.connect("clicked", lambda *_: cb())
        return b

    def row(self, widgets, center=True):
        r = Gtk.Box(spacing=6, homogeneous=False, halign=Gtk.Align.CENTER if center else Gtk.Align.FILL)
        for w in widgets:
            r.pack_start(w, w.get_hexpand(), True, 0)
        return r

    def build(self):
        for c in self.rows_box.get_children():
            c.destroy()
        self.chars = []
        rows = SYMBOLS if self.symbols else LETTERS
        if self.polish and not self.symbols:
            self.rows_box.pack_start(self.row([self.char_btn(c) for c in PL]), False, False, 0)
        for i, keys in enumerate(rows):
            widgets = []
            if i == 3 and not self.symbols:
                widgets.append(self.btn("⇧", self.on_shift, "special" if not (self.shift or self.caps) else "on", 64))
            for c in keys:
                widgets.append(self.char_btn(c))
            if i == 3:
                widgets.append(self.btn("⌫", lambda: self.on_key("key", "BackSpace"), "special", 64))
            self.rows_box.pack_start(self.row(widgets), False, False, 0)
        bottom = [self.btn("123" if not self.symbols else "ABC", self.on_symbols, "special", 70),
                  self.btn("◀", lambda: self.on_key("key", "Left"), "special", 52),
                  self.btn("Spacja", lambda: self.on_key("char", " "), None, 300),
                  self.btn("▶", lambda: self.on_key("key", "Right"), "special", 52),
                  self.btn("Tab", lambda: self.on_key("key", "Tab"), "special", 56),
                  self.btn("Enter", lambda: self.on_key("key", "Return"), "accent", 90),
                  self.btn("⌄", lambda: self.on_key("key", "Hide"), "special", 52)]
        self.rows_box.pack_start(self.row(bottom), False, False, 0)
        self.rows_box.show_all()

    def char_btn(self, c):
        up = c.upper() if c.isalpha() else c
        upper = self.shift or self.caps
        b = Gtk.Button(label=up if upper else c)
        b.set_size_request(46, -1)
        b.connect("clicked", lambda *_, ch=c: self.press_char(ch))
        return b

    # ---------------------------------------------------- actions
    def press_char(self, c):
        out = c.upper() if (self.shift or self.caps) and c.isalpha() else c
        self.on_key("char", out)
        if self.shift and not self.caps:
            self.shift = False
            self.build()

    def on_shift(self):
        if self.shift:
            self.shift, self.caps = False, True
        elif self.caps:
            self.caps = False
        else:
            self.shift = True
        self.build()

    def on_symbols(self):
        self.symbols = not self.symbols
        self.build()

    def first_button(self):
        for r in self.rows_box.get_children():
            for b in r.get_children():
                return b
        return None
