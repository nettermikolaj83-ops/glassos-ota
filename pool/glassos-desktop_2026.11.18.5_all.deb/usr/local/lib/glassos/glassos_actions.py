"""GlassOS: what the voice assistant (Rozmowa z AI) may do on the computer.

The AI answers in words and, on separate lines, with commands like
    >> OTWÓRZ_APLIKACJĘ: Kalkulator
Only the commands listed here exist; nothing deletes files or runs shell
commands. Installed as /usr/local/lib/glassos/glassos_actions.py.
"""
import json
import os
import re
import subprocess
import sys
import time
import urllib.parse
import uuid

sys.path.insert(0, "/usr/local/lib/glassos")

SYNONYMS = {"przeglądarka": "chromium", "przegladarka": "chromium", "chrome": "chromium", "internet": "chromium",
            "google chrome": "chromium", "pliki": "thunar", "menedżer plików": "thunar", "eksplorator": "thunar",
            "terminal": "xfce4-terminal", "konsola": "xfce4-terminal", "notatnik": "mousepad",
            "edytor tekstu": "mousepad", "sklep": "glassos-appstore", "app store": "glassos-appstore",
            "ustawienia": "glassos-settings", "kalkulator": "calculator", "muzyka": "glassos-music",
            "zdjęcia": "glassos-photos", "galeria": "glassos-photos", "kalendarz": "glassos-calendar",
            "zegar": "glassos-clock", "tłumacz": "glassos-translate", "asystent": "glassos-ai", "hasła": "glassos-passwords",
            "kamera": "glassos-camera", "steam": "steam", "minecraft": "prismlauncher"}

PANES = {"wygląd": "appearance", "tapeta": "wallpaper", "wifi": "wifi", "wi-fi": "wifi", "bluetooth": "bluetooth",
         "dźwięk": "sound", "monitory": "display", "ekran": "display", "bateria": "battery", "aktualizacje": "updates",
         "drukarki": "printers", "użytkownicy": "users", "skróty": "shortcuts", "skupienie": "focus",
         "czas przed ekranem": "screentime", "kopie zapasowe": "backup", "pamięć": "storage"}

HELP = """Możesz też sterować komputerem. Gdy użytkownik prosi o zrobienie czegoś, najpierw krótko powiedz, co robisz,
a potem w osobnych liniach dopisz polecenia (każde w nowej linii, zaczynając od >>). Dostępne polecenia:
>> OTWÓRZ_APLIKACJĘ: nazwa            (np. Kalkulator, Chromium, Pliki, Terminal, Muzyka, Ustawienia)
>> OTWÓRZ_STRONĘ: adres               (np. allegro.pl)
>> SZUKAJ: zapytanie                  (wyszukiwanie w internecie)
>> YOUTUBE: zapytanie                 (wyszukaj i otwórz na YouTube)
>> PISZ: tekst                        (wpisuje tekst w aktywnym oknie)
>> KLAWISZE: skrót                    (np. ctrl+t, ctrl+w, alt+f4, enter, ctrl+s)
>> ZAMKNIJ: nazwa aplikacji           (zamyka jej okna)
>> MINIMALIZUJ: nazwa aplikacji
>> POKAŻ_PULPIT
>> PULPIT: numer                      (1-4)
>> MOTYW: ciemny albo jasny
>> GŁOŚNOŚĆ: liczba 0-100
>> MINUTNIK: minuty | nazwa
>> MUZYKA: graj / pauza / następny / poprzedni
>> SKUPIENIE: włącz albo wyłącz
>> USTAWIENIA: część                  (np. wifi, bluetooth, tapeta, dźwięk, monitory, bateria)
>> NARYSUJ: opis obrazu               (AI narysuje obraz w Kreatorze obrazów)
>> ZRZUT_EKRANU
>> ZABLOKUJ_EKRAN
Używaj poleceń tylko wtedy, gdy użytkownik o coś prosi. Nie wymyślaj innych poleceń.
Przykład – użytkownik: „otwórz YouTube i puść lofi”. Ty:
Już włączam lofi na YouTube.
>> YOUTUBE: lofi hip hop"""

ACTION_RE = re.compile(r"^\s*>>\s*([A-ZĄĆĘŁŃÓŚŹŻ_]+)\s*(?::\s*(.*))?$")


def split(text):
    """AI answer -> (spoken text, [(command, argument)])"""
    said, acts = [], []
    for line in text.splitlines():
        m = ACTION_RE.match(line)
        if m:
            acts.append((m.group(1), (m.group(2) or "").strip()))
        elif not line.strip().startswith(">>"):
            said.append(line)
    return "\n".join(said).strip(), acts


def strip_partial(text):
    """While streaming: the spoken part only (drops commands, even half-written)."""
    out = []
    for line in text.split("\n"):
        if line.lstrip().startswith(">") or line.lstrip().startswith("—>"):
            break
        out.append(line)
    return "\n".join(out)


def _spawn(argv):
    subprocess.Popen(argv, start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def find_app(name):
    import gi
    gi.require_version("Gio", "2.0")
    from gi.repository import Gio
    q = name.lower().strip().strip(".")
    q = SYNONYMS.get(q, q)
    best, score = None, 0
    for a in Gio.AppInfo.get_all():
        if not a.should_show():
            continue
        names = [a.get_display_name() or "", a.get_id() or "", os.path.basename((a.get_executable() or ""))]
        if isinstance(a, Gio.DesktopAppInfo):
            names += [a.get_generic_name() or ""] + list(a.get_keywords() or [])
        for n in names:
            n = n.lower().replace(".desktop", "")
            s = 100 if n == q else 80 if n.startswith(q) else 60 if q in n else 0
            if s > score:
                best, score = a, s
    return best


def app_ids_for(name):
    """Wayland app ids of the open windows of the app called name."""
    import wfipc
    q = SYNONYMS.get(name.lower().strip(), name.lower().strip())
    out = []
    for v in wfipc.app_views():
        aid = (v.get("app-id") or "").lower()
        title = (v.get("title") or "").lower()
        if q in aid or aid in q or q in title:
            out.append(v)
    if not out:
        a = find_app(name)
        if a:
            stem = (a.get_id() or "").replace(".desktop", "").lower()
            out = [v for v in wfipc.app_views() if stem and (stem in (v.get("app-id") or "").lower())]
    return out


def keys(combo):
    """'ctrl+shift+t' -> wtype arguments"""
    mods = {"ctrl": "ctrl", "control": "ctrl", "alt": "alt", "shift": "shift", "super": "logo", "win": "logo",
            "logo": "logo"}
    names = {"enter": "Return", "return": "Return", "esc": "Escape", "escape": "Escape", "tab": "Tab",
             "spacja": "space", "space": "space", "backspace": "BackSpace", "delete": "Delete", "del": "Delete",
             "góra": "Up", "dół": "Down", "lewo": "Left", "prawo": "Right", "up": "Up", "down": "Down",
             "left": "Left", "right": "Right", "home": "Home", "end": "End", "pageup": "Prior", "pagedown": "Next"}
    parts = [p.strip().lower() for p in combo.replace(" ", "").split("+") if p.strip()]
    ms = [mods[p] for p in parts if p in mods]
    rest = [p for p in parts if p not in mods]
    args = []
    for m in ms:
        args += ["-M", m]
    for r in rest:
        if r in names:
            args += ["-k", names[r]]
        elif re.fullmatch(r"f\d{1,2}", r):
            args += ["-k", r.upper()]
        else:
            args += [r]
    for m in reversed(ms):
        args += ["-m", m]
    return args


def run(cmd, arg):
    """Do one command. -> short Polish description of what happened (for the log)."""
    cmd = cmd.upper().replace("Ó", "O").replace("Ę", "E").replace("Ł", "L").replace("Ś", "S").replace("Ą", "A") \
        .replace("Ć", "C").replace("Ń", "N").replace("Ż", "Z").replace("Ź", "Z")
    try:
        if cmd == "OTWORZ_APLIKACJE":
            a = find_app(arg)
            if not a:
                return f"nie znalazłem aplikacji {arg}"
            a.launch([], None)
            return f"otwarto {a.get_display_name()}"
        if cmd == "OTWORZ_STRONE":
            url = arg if re.match(r"^[a-z]+://", arg) else "https://" + arg.strip("/ ")
            _spawn(["xdg-open", url])
            return f"otwarto {url}"
        if cmd == "SZUKAJ":
            _spawn(["xdg-open", "https://duckduckgo.com/?q=" + urllib.parse.quote(arg)])
            return f"szukam {arg}"
        if cmd == "YOUTUBE":
            _spawn(["xdg-open", "https://www.youtube.com/results?search_query=" + urllib.parse.quote(arg)])
            return f"YouTube: {arg}"
        if cmd == "PISZ":
            time.sleep(0.3)
            subprocess.run(["wtype", "-d", "6", "--", arg])
            return "wpisano tekst"
        if cmd == "KLAWISZE":
            subprocess.run(["wtype"] + keys(arg))
            return f"naciśnięto {arg}"
        if cmd in ("ZAMKNIJ", "MINIMALIZUJ"):
            import wfipc
            vs = app_ids_for(arg)
            for v in vs:
                (wfipc.close if cmd == "ZAMKNIJ" else wfipc.minimize)(v["id"])
            return f"{cmd.lower()}: {len(vs)} okien"
        if cmd == "POKAZ_PULPIT":
            import wfipc
            wfipc.show_desktop()
            return "pulpit"
        if cmd == "PULPIT":
            n = int(re.sub(r"\D", "", arg) or 1)
            _spawn(["/usr/local/bin/glassos-wf", "workspace", str(max(1, min(4, n)))])
            return f"pulpit {n}"
        if cmd == "MOTYW":
            t = "light" if arg.lower().startswith(("jas", "light")) else "dark"
            _spawn(["/usr/local/bin/glassos-theme", "--theme", t])
            return f"motyw {t}"
        if cmd == "GLOSNOSC":
            v = max(0, min(150, int(re.sub(r"\D", "", arg) or 50)))
            subprocess.run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "0"])
            subprocess.run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{v}%"])
            return f"głośność {v}%"
        if cmd == "MINUTNIK":
            parts = [p.strip() for p in arg.split("|")]
            mins = float(re.sub(r"[^\d.,]", "", parts[0]).replace(",", ".") or 5)
            data = os.path.join(os.path.expanduser("~/.local/share/glassos"), "clock.json")
            try:
                d = json.load(open(data))
            except (OSError, ValueError):
                d = {}
            d.setdefault("timers", []).append({"id": uuid.uuid4().hex[:8], "end": time.time() + mins * 60,
                                               "label": parts[1] if len(parts) > 1 else "", "dur": int(mins * 60)})
            os.makedirs(os.path.dirname(data), exist_ok=True)
            json.dump(d, open(data, "w"), ensure_ascii=False)
            _spawn(["/usr/local/bin/glassos-reminderd"])
            return f"minutnik {mins:g} min"
        if cmd == "MUZYKA":
            method = {"graj": "Play", "play": "Play", "pauza": "Pause", "stop": "Pause", "następny": "Next",
                      "nastepny": "Next", "dalej": "Next", "poprzedni": "Previous"}.get(arg.lower().split()[0] if arg
                                                                                         else "graj", "PlayPause")
            names = subprocess.run(["busctl", "--user", "list", "--no-legend"], capture_output=True, text=True).stdout
            players = [ln.split()[0] for ln in names.splitlines() if ln.startswith("org.mpris.MediaPlayer2.")]
            if not players:
                _spawn(["/usr/local/bin/glassos-music"])
                return "otwarto Muzykę"
            subprocess.run(["gdbus", "call", "--session", "--dest", players[0], "--object-path",
                            "/org/mpris/MediaPlayer2", "--method", f"org.mpris.MediaPlayer2.Player.{method}"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"muzyka: {method}"
        if cmd == "SKUPIENIE":
            _spawn(["/usr/local/bin/glassos-focus", "off" if arg.lower().startswith("wy") else "on"])
            return "tryb skupienia"
        if cmd == "USTAWIENIA":
            pane = PANES.get(arg.lower().strip(), "general")
            _spawn(["/usr/local/bin/glassos-settings", "--pane", pane])
            return f"ustawienia {pane}"
        if cmd == "NARYSUJ":
            _spawn(["/usr/local/bin/glassos-imagine", "--prompt", arg])
            return f"rysuję: {arg}"
        if cmd == "ZRZUT_EKRANU":
            _spawn(["/usr/local/bin/glassos-screenshot", "full"])
            return "zrzut ekranu"
        if cmd == "ZABLOKUJ_EKRAN":
            _spawn(["/usr/local/bin/glassos-lock"])
            return "blokada"
    except Exception as e:      # noqa: BLE001  one bad command must not end the conversation
        return f"błąd: {e}"
    return f"nieznane polecenie {cmd}"
